package com.earljohn.themepicker

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        applySavedTheme()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val themeText = findViewById<TextView>(R.id.themeText)
        val theme = prefs.getString("theme", "Light")
        themeText.text = "Current theme: $theme"

        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun applySavedTheme() {
        when (prefs.getString("theme", "Light")) {
            "Dark" -> setTheme(R.style.AppTheme_Dark)
            "Colorful" -> setTheme(R.style.AppTheme_Colorful)
            else -> setTheme(R.style.AppTheme_Light)
        }
    }


    override fun onResume() {
        super.onResume()
        recreate() // To reflect the changed theme after return
    }
}
