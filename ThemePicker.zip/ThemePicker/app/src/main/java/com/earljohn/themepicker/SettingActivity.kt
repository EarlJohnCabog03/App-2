package com.earljohn.themepicker

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)

        findViewById<Button>(R.id.btnLight).setOnClickListener {
            prefs.edit().putString("theme", "Light").apply()
            finish()
        }

        findViewById<Button>(R.id.btnDark).setOnClickListener {
            prefs.edit().putString("theme", "Dark").apply()
            finish()
        }

        findViewById<Button>(R.id.btnColorful).setOnClickListener {
            prefs.edit().putString("theme", "Colorful").apply()
            finish()
        }
    }
}
